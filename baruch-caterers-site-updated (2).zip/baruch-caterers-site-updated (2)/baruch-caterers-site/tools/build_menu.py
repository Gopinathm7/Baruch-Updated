#!/usr/bin/env python3
"""Regenerates the menu block in menu.html. Edit ITEMS below (add dishes), then run: python3 tools/build_menu.py"""
import re, html, pathlib
ROOT = pathlib.Path(__file__).resolve().parent.parent
TITLES = """Sweets Varieties|Pongal Varieties|Dosa Varieties|Idly Varieties|Kichidi Varieties|Poori Varieties|Sevai Varieties|Paniyaram Varieties|Karaikudi Menu|Vada Varieties|Vada Varieties (Dinner)|Sambar Varieties|Sambar Varieties (Lunch)|Chutney Varieties|Upma Varieties|Pickle Varieties|Pickle Varieties (Dinner)|Biryani Varieties|Biryani Varieties (Dinner)|Rice Varieties|Raita Varieties|Dhal Varieties|Pulikozhambu Varieties|Curd Varieties|Mor Kulambu Varieties|Rasam Varieties|Poriyal Varieties (Chilli/Fry)|Appalam Varieties|Payasam Varieties|Poriyal Varieties (Kootu/Chops)|Soups|Salads|Starters|Indian Breads|Gravy Varieties|Ice Cream|Fresh Juice|Mocktails|Milkshakes|Chocolate Factory|Momos|Smoothies|Mexican|Main Course""".split("|")
NONVEG = [("Chicken Starters","starters"),("Mutton Starters","karaikudi-menu"),("Chicken Main Course","gravy-varieties"),("Mutton Main Course","main-course"),("Biryani & Rice","biryani-varieties"),("Fish & Seafood Starters","starters"),("Seafood Main Course","gravy-varieties"),("Egg Dishes","paniyaram-varieties"),("Breads & Tiffin","indian-breads"),("Accompaniments","raita-varieties")]
IMG = dict(NONVEG); IMG.update({"Poriyal Varieties (Chilli/Fry)":"poriyal-chilli-fry","Poriyal Varieties (Kootu/Chops)":"poriyal-kootu-chops"})
# Items per category: list of (tag, group title, [dishes]). Categories not listed show "full list on request".
ITEMS = {"Sweets Varieties": [
("Premium Nut Collection","Badam, Pista & Cashewnut Sweets","Cashew Cake|Kaju Katli|Badam Cake|Badam Tilak|Badam Katli|Badam Roll|Badam Fig Roll|Badam Halwa|Pista Katli|Pista Roll|Bournvitta Cake|Rose Ladoo|Coconut Tango|Fried Kaju Biscuit|Dry Fruits Chikki|Badam Cutlet|Badam Mysurpa|Konke Ladoo"),
("Classic Collection","Khova Sweets","Makken Peda|Black Jamuns|Gulab Jamun|Malai Apple|Kalingan|Agra Paan|Bread Malpua|Real Malpua"),
("Traditional Favourites","Maida & Besan Sweets","Soan Papdi|Maida Cake|Chocolate Soan Papdi|Chocolate Burfi|Carrot Burfi|Coconut Burfi|Carrot Mysorepak|Mysore Pak|Bombay Ladoo|Real Mango Roll|Chikoo Roll|Fruit Delight|Chocolate Canary|Orange Tango|Tawa Mithai|Paruthipaal Panangkarupatti Mysorepak|Badusha|Butter Strawberry - Rasagulla|Apple Jelebi|Paneer Jelebi|Milky Taka Tak"),
("Rich & Creamy","Milk Sweets","Basundhi|Angoor Rabdi|Champakali|Honey Dew|Rasamalai|Rasagulla|Sandesh|Chum Chum|Dhood Peda|Kalakand|Malai Kaja|Malpua|Paneer Jelebi|Agra Paan|Mahai Paan"),
("Warm Indulgence","Halwa Varieties","Pumpkin Halwa|Carrot Halwa|Dates Halwa|Milk Halwa|Moongdal Halwa|Wheat Halwa|Apricot Halwa|Rava Kesari|Pineapple Kesari|Kasi Halwa|Paruthipaal Panangkaruppatti Halwa|Panangkaruppatti Halwa|Ragi Pineapple Halwa|Dry Fruits Halwa|Guava Kesari|Mango Kesari")]}
import json
RENAME = {'Vada Varieties (Breakfast)': 'Vada Varieties', 'Sambar Varieties (Breakfast)': 'Sambar Varieties', 'Biryani Varieties (Lunch)': 'Biryani Varieties', 'Raitha Varieties': 'Raita Varieties'}
LIVE = json.loads((ROOT/"tools"/"live-menu-data.json").read_text(encoding="utf-8"))  # copied from the live site's menu-catalog-v2.js and non-veg-menu-catalog.js
for c in LIVE["veg"] + LIVE["nonveg"]:
    ITEMS[RENAME.get(c["title"], c["title"])] = [(c["period"], "Select your dishes", "|".join(c["items"]))]
e = html.escape
slug = lambda t: re.sub(r"[^a-z0-9]+","-",t.lower()).strip("-")
cards, nvcards, panels = [], [], []
for t, DIET in [(x, "veg") for x in TITLES] + [(x[0], "non-veg") for x in NONVEG]:
    s, img = slug(t), IMG.get(t, slug(re.sub(r"\s*\(.*\)","",t)))
    groups = ITEMS.get(t, [])
    n = sum(len(g[2].split("|")) for g in groups)
    sub = f"{n} items" if n else "Full list on request"
    (cards if DIET == "veg" else nvcards).append(f'<button type="button" class="dish-card cat-card" data-open="{s}"><img src="assets/images/cuisine-items/{img}.webp" alt="{e(t)} catering menu by Baruch Caterers Chennai" width="300" height="180" loading="lazy"><div class="dish-body"><h3>{e(t)}</h3><p>{sub}<span class="sel-badge" data-badge="{s}" hidden></span></p></div></button>')
    body = ""
    for tag, gt, dishes in groups:
        d = dishes.split("|")
        lis = "".join(f'<li><label class="pick"><input type="checkbox" data-cat="{s}" data-catname="{e(t)}" value="{e(x)}"><span>{e(x)}</span></label></li>' for x in d)
        body += f'<div class="menu-group"><span class="section-label">{e(tag)}</span><h3>{e(gt)}</h3><p class="grp-count">{len(d)} varieties</p><ul class="pick-list">{lis}</ul></div>'
    if not body:
        body = f'<div class="menu-group"><p>The full {e(t)} list is shared on request. Message us on WhatsApp and we will send it with your quote.</p><a class="btn btn-maroon btn-small" href="https://wa.me/919087618761?text=Hi%20Baruch%20Caterers%2C%20please%20share%20the%20{e(t).replace(" ","%20")}%20list.">Ask on WhatsApp</a></div>'
    search = '<input type="search" class="menu-search" placeholder="Search within this category" aria-label="Search within this category">' if groups else ""
    panels.append(f'<div class="menu-panel" id="panel-{s}" hidden><button type="button" class="btn btn-outline-dark btn-small" data-back>&larr; All categories</button><h2>{e(t)}</h2>{search}{body}</div>')
BLOCK = f'''<!--MENU-START-->
<section class="bg-ivory" id="cuisine">
  <div class="container">
    <div class="section-head">
      <span class="section-label">Cuisine selection</span>
      <h2>Select a category to explore every menu item.</h2>
      <p>Tick the dishes you like, move between categories, then review your list and send it to us on WhatsApp as a message or PDF. Your choices stay saved while you browse.</p>
    </div>
    <div id="cat-grid"><div class="diet-tabs" role="tablist"><button type="button" class="active" data-tab="veg">&#127807; Veg Menu</button><button type="button" data-tab="non-veg">&#127830; Non-Veg Menu</button></div><div class="grid-3" data-diet="veg">{"".join(cards)}</div><div class="grid-3" data-diet="non-veg" hidden>{"".join(nvcards)}</div></div>
    <div id="panels">{"".join(panels)}</div>
  </div>
</section>
<button type="button" class="cart-fab" id="cart-open" aria-label="Review selected items">&#127860; My selection <b id="cart-count">0</b></button>
<div class="cart-overlay" id="cart-overlay" hidden></div>
<aside class="cart-drawer" id="cart-drawer" aria-label="Selected menu items" hidden>
  <div class="cart-head"><h2>My selection</h2><button type="button" id="cart-close" aria-label="Close">&times;</button></div>
  <div id="cart-list" class="cart-list"></div>
  <form id="enquiry" class="cart-form" onsubmit="return false">
    <input name="name" placeholder="Your name" required autocomplete="name">
    <input name="phone" type="tel" placeholder="Phone number" autocomplete="tel">
    <input name="event" placeholder="Event type (wedding, birthday...)">
    <input name="date" type="date" aria-label="Event date">
    <input name="guests" type="number" min="1" placeholder="Number of guests">
    <input name="venue" placeholder="Venue / area">
    <textarea name="notes" rows="2" placeholder="Notes (optional)"></textarea>
  </form>
  <div class="cart-actions">
    <button type="button" class="btn btn-maroon" id="send-wa">Send on WhatsApp</button>
    <button type="button" class="btn btn-gold" id="send-pdf">Get PDF &amp; share on WhatsApp</button>
    <button type="button" class="btn-link" id="cart-clear">Clear selection</button>
  </div>
</aside>
<!--MENU-END-->'''
p = ROOT/"menu.html"; s = p.read_text(encoding="utf-8")
if "<!--MENU-START-->" in s:
    s = re.sub(r"<!--MENU-START-->.*<!--MENU-END-->", lambda m: BLOCK, s, flags=re.S)
else:
    s, k = re.subn(r'<section class="bg-ivory">\s*<div class="container">\s*<div class="section-head">\s*<span class="section-label">Cuisine selection.*?</section>', lambda m: BLOCK, s, count=1, flags=re.S)
    assert k == 1
    s = s.replace('<script src="assets/js/main.js"></script>', '<script src="assets/js/main.js"></script>\n<script src="assets/js/menu.js"></script>')
p.write_text(s, encoding="utf-8"); print("menu.html updated:", len(TITLES), "categories")
