// Baruch Caterers — shared site behaviour
document.addEventListener("DOMContentLoaded", function () {
  // Mobile nav toggle
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        nav.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  // Gallery category filter (gallery.html)
  var filterButtons = document.querySelectorAll(".gallery-filters button");
  var galleryItems = document.querySelectorAll(".gallery-grid [data-category]");
  if (filterButtons.length && galleryItems.length) {
    filterButtons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        filterButtons.forEach(function (b) { b.classList.remove("active"); });
        btn.classList.add("active");
        var category = btn.getAttribute("data-filter");
        galleryItems.forEach(function (item) {
          var match = category === "all" || item.getAttribute("data-category") === category;
          item.style.display = match ? "" : "none";
        });
      });
    });
  }
});
