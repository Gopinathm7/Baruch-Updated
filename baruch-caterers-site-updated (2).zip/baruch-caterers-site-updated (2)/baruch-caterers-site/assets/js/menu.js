// Baruch Caterers — menu selection, cart, WhatsApp message and PDF
(function () {
  var WA = "919087618761", KEY = "baruchSelection", sel = {};
  try { sel = JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) {}
  var $ = function (s, r) { return (r || document).querySelector(s); }, $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var grid = $("#cat-grid"); if (!grid) return;
  function save() { try { localStorage.setItem(KEY, JSON.stringify(sel)); } catch (e) {} }
  function total() { return Object.keys(sel).reduce(function (n, c) { return n + sel[c].items.length; }, 0); }
  function sync() {
    $$("#panels input[type=checkbox]").forEach(function (i) { i.checked = !!(sel[i.dataset.cat] && sel[i.dataset.cat].items.indexOf(i.value) > -1); });
    $$("[data-badge]").forEach(function (b) { var n = sel[b.dataset.badge] ? sel[b.dataset.badge].items.length : 0; b.hidden = !n; b.textContent = n ? " · " + n + " selected" : ""; });
    $("#cart-count").textContent = total(); renderCart();
  }
  function toggle(cat, name, title, on) {
    var c = sel[cat] || (sel[cat] = { title: title, items: [] }), i = c.items.indexOf(name);
    if (on && i < 0) c.items.push(name); if (!on && i > -1) c.items.splice(i, 1);
    if (!c.items.length) delete sel[cat]; save(); sync();
  }
  function renderCart() {
    var box = $("#cart-list"), keys = Object.keys(sel);
    if (!keys.length) { box.innerHTML = "<p class='cart-empty'>No dishes selected yet. Open a category and tick the dishes you like.</p>"; return; }
    box.innerHTML = keys.map(function (c) {
      return "<div class='cart-cat'><h3>" + sel[c].title + "</h3><ul>" + sel[c].items.map(function (n) {
        return "<li><span></span><button type='button' data-rm='" + c + "' aria-label='Remove'>&times;</button></li>";
      }).join("") + "</ul></div>";
    }).join("");
    $$(".cart-cat", box).forEach(function (el, k) { $$("li", el).forEach(function (li, j) { li.firstChild.textContent = sel[keys[k]].items[j]; li.lastChild.dataset.name = sel[keys[k]].items[j]; }); });
  }
  grid.addEventListener("click", function (e) { var b = e.target.closest("[data-tab]"); if (!b) return; $$("[data-tab]").forEach(function (x) { x.classList.toggle("active", x === b); }); $$("[data-diet]", grid).forEach(function (g) { g.hidden = g.dataset.diet !== b.dataset.tab; }); });
  function show(id) { $$(".menu-panel").forEach(function (p) { p.hidden = p.id !== "panel-" + id; }); grid.hidden = !!id; if (id) $("#cuisine").scrollIntoView({block:"start"}); }
  grid.addEventListener("click", function (e) { var b = e.target.closest("[data-open]"); if (b) show(b.dataset.open); });
  $("#panels").addEventListener("click", function (e) { if (e.target.closest("[data-back]")) show(null); });
  $("#panels").addEventListener("change", function (e) { var i = e.target; if (i.dataset.cat) toggle(i.dataset.cat, i.value, i.dataset.catname, i.checked); });
  $("#panels").addEventListener("input", function (e) {
    if (!e.target.classList.contains("menu-search")) return; var q = e.target.value.toLowerCase();
    $$("li", e.target.parentNode).forEach(function (li) { li.hidden = li.textContent.toLowerCase().indexOf(q) < 0; });
  });
  function drawer(open) { $("#cart-drawer").hidden = !open; $("#cart-overlay").hidden = !open; }
  $("#cart-open").onclick = function () { drawer(true); }; $("#cart-close").onclick = $("#cart-overlay").onclick = function () { drawer(false); };
  $("#cart-list").addEventListener("click", function (e) { var b = e.target.closest("[data-rm]"); if (b) toggle(b.dataset.rm, b.dataset.name, "", false); });
  $("#cart-clear").onclick = function () { sel = {}; save(); sync(); };
  function details() { var f = $("#enquiry"), v = function (n) { return f.elements[n].value.trim(); }; return { name: v("name"), phone: v("phone"), event: v("event"), date: v("date"), guests: v("guests"), venue: v("venue"), notes: v("notes") }; }
  function ready() {
    if (!total()) { alert("Please select at least one dish first."); return null; }
    if (!$("#enquiry").elements.name.value.trim()) { $("#enquiry").elements.name.focus(); alert("Please enter your name."); return null; }
    return details();
  }
  function lines(d) {
    var o = ["Hi Baruch Caterers, I would like a quote for my event.", ""];
    [["Name", d.name], ["Phone", d.phone], ["Event", d.event], ["Date", d.date], ["Guests", d.guests], ["Venue", d.venue]].forEach(function (r) { if (r[1]) o.push(r[0] + ": " + r[1]); });
    o.push("", "*Selected menu (" + total() + " items)*");
    Object.keys(sel).forEach(function (c) { o.push("", "*" + sel[c].title + "*"); sel[c].items.forEach(function (n, i) { o.push((i + 1) + ". " + n); }); });
    if (d.notes) o.push("", "Notes: " + d.notes);
    return o;
  }
  function openWA(text) { window.open("https://wa.me/" + WA + "?text=" + encodeURIComponent(text), "_blank"); }
  $("#send-wa").onclick = function () { var d = ready(); if (d) openWA(lines(d).join("\n")); };
  function loadPdf(cb) {
    if (window.jspdf) return cb();
    var s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"; s.onload = cb;
    s.onerror = function () { alert("Could not load the PDF tool. Please use 'Send on WhatsApp' instead."); }; document.head.appendChild(s);
  }
  function makePdf(d) {
    var doc = new window.jspdf.jsPDF({ unit: "mm", format: "a4" }), y = 20, W = 210, M = 18;
    function line(t, size, bold, gap) { doc.setFontSize(size); doc.setFont("helvetica", bold ? "bold" : "normal"); doc.splitTextToSize(t, W - 2 * M).forEach(function (l) { if (y > 280) { doc.addPage(); y = 20; } doc.text(l, M, y); y += gap; }); }
    doc.setTextColor(138, 36, 50); line("Baruch Caterers - Menu Selection", 18, true, 9);
    doc.setTextColor(36, 30, 25); line("Chennai | 90 8761 8761 | baruchcaterers.com", 10, false, 8);
    [["Name", d.name], ["Phone", d.phone], ["Event", d.event], ["Date", d.date], ["Guests", d.guests], ["Venue", d.venue]].forEach(function (r) { if (r[1]) line(r[0] + ": " + r[1], 11, false, 6); });
    y += 4; Object.keys(sel).forEach(function (c) {
      y += 3; doc.setTextColor(27, 59, 44); line(sel[c].title + " (" + sel[c].items.length + ")", 13, true, 7); doc.setTextColor(36, 30, 25);
      sel[c].items.forEach(function (n, i) { line((i + 1) + ". " + n, 11, false, 5.6); });
    });
    if (d.notes) { y += 5; line("Notes: " + d.notes, 11, false, 6); }
    return doc;
  }
  $("#send-pdf").onclick = function () {
    var d = ready(); if (!d) return;
    loadPdf(function () {
      var doc = makePdf(d), name = "Baruch-Caterers-Menu-Selection.pdf", file = new File([doc.output("blob")], name, { type: "application/pdf" });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], title: "Menu selection", text: "Menu selection for Baruch Caterers (+91 90876 18761)" }).catch(function () {});
      } else {
        doc.save(name);
        alert("Your PDF has been downloaded. WhatsApp will open next: please attach the PDF to the chat.");
        openWA("Hi Baruch Caterers, I am sending my menu selection PDF for a quote. Name: " + d.name + (d.event ? ", Event: " + d.event : ""));
      }
    });
  };
  sync();
})();
